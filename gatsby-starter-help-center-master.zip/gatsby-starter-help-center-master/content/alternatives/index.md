---
title: Alternatives
date: 2020-01-02
author: dferber
modifiedDate: null
description: "An overview of alternatives"
---

This is a list of alternative help center services.

## Free

- [customerly](https://www.customerly.io/en/knowledgebase-help-center-software-platform) (for up to 2 users, then \$24 per month)

## Paid

- [helpdocs.io](https://www.helpdocs.io/) (\$49 per month)
- [intercom.com](https://www.intercom.com/customer-support-software/knowledge-base) (\$49 per month on top of regular plan)
- [fullhelp.com](https://www.fullhelp.com/en) (\$99 for first year, \$89 afterwards)
- [kommunicate.io](https://www.kommunicate.io/product/helpcenter) ($0 - $20 per month)
- [helpcrunch.com](https://helpcrunch.com/knowledge-base.html) (15€ per month per team member)
- [dashly.io](https://www.dashly.io/knowledgebase) (\$15 on top of your regular plan)
- [knowledgebase.ai](https://www.knowledgebase.ai/) (\$39 per month)
- [document360.io](https://document360.io/) (\$59 per month)
